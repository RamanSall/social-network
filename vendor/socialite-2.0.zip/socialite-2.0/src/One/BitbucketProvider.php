<?php

namespace Laravel\Socialite\One;

class BitbucketProvider extends AbstractProvider
{
    //
}
