<?php

namespace Laravel\Socialite\Two;

class InvalidStateException extends \InvalidArgumentException
{
    //
}
